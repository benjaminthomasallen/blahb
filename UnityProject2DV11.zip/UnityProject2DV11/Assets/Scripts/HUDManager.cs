﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HUDManager : MonoBehaviour
{
    private GameplayManager GPMScript;

    public Text armySizeText;
    public Text resourceText;
    public Text infoText;
    public Text victoryText;
    public Text currentTurnText;

    private string currentUnit;
    private string unitTeam;
    private int hp;
    private int atk;
    private int def;
    private int move;
    private int sight;
    private int range;

    private int turn_color;
    private int resource_red = 0;
    private int resource_blue = 0;
    private int red_victory = 0;
    private int blue_victory = 0;
    private int red_army = 0;
    private int blue_army = 0;
    private int cur_army = 0;
    private int cur_res = 0;

    private string currentTurn;

    private DefaultUnit unitdata;

    // Use this for initialization
    void Start()
    {
        GPMScript = GameObject.Find("GameManager(Clone)").GetComponent<GameplayManager>();

        setResVal();
        whichRes();
        resourceText.text = "Resources:\n" + cur_res;

        setArmyVal();
        whichArmy();
        armySizeText.text = "Army Size:\n" +  cur_army;

        setVictory();
        victoryText.text = "Victory Pts:\n" + red_victory+ "-" + blue_victory + "\nRed - Blue";
        if(turn_color == 3)
        {
            if(red_victory > blue_victory)
            {
                victoryText.text = "RED WINS WITH:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
            }
            else if (red_victory < blue_victory)
            {
                victoryText.text = "BLUE WINS WITH:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
            }
            else
            {
                victoryText.text = "A TIE WITH:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
            }
        }

        setCurrentTurn();
        currentTurnText.text = "Current Turn:\n" + currentTurn;

        getUnitInfo();
        infoText.text = "Unit: " + currentUnit + "\nTeam: " + unitTeam + "\n\nHP: " + hp + "\nAtk: " + atk + "\nDef: " + def + "\nMove: " + move + "\nSight: " + sight + "\nRange: " + range;
    }

    // Update is called once per frame
    void Update()
    {
        setResVal();
        whichRes();
        resourceText.text = "Resources:\n" + cur_res;

        setArmyVal();
        whichArmy();
        armySizeText.text = "Army Size:\n" + cur_army;

        setVictory();
        victoryText.text = "Victory Pts:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
        if (turn_color == 3)
        {
            if (red_victory > blue_victory)
            {
                victoryText.text = "RED WINS WITH:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
            }
            else if (red_victory < blue_victory)
            {
                victoryText.text = "BLUE WINS WITH:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
            }
            else
            {
                victoryText.text = "A TIE WITH:\n" + red_victory + "-" + blue_victory + "\nRed - Blue";
            }
        }

        setCurrentTurn();
        currentTurnText.text = "Current Turn:\n" + currentTurn;

        getUnitInfo();
        infoText.text = "Unit: " + currentUnit + "\nTeam: " + unitTeam + "\n\nHP: " + hp + "\nAtk: " + atk + "\nDef: " + def + "\nMove: " + move + "\nSight: " + sight + "\nRange: " + range;

    }

    private void getUnitInfo()
    {
        unitdata = GPMScript.getData();
        currentUnit = unitdata.type;
        hp = unitdata.hp;
        atk = unitdata.att;
        def = unitdata.def;
        move = unitdata.move;
        sight = unitdata.sight;
        range = unitdata.range;
        if (unitdata.whichteam() == 1)
        {
            unitTeam = "Red";
        }
        else
        {
            unitTeam = "Blue";
        }
    }

    public void setCurrentTurn()
    {
        turn_color = GPMScript.getTurnColor();
        if(turn_color == 1)
        {
            currentTurn = "RED";
        }
        else
        {
            currentTurn = "BLUE";
        }
    }

    private void setVictory()
    {
        red_victory = GPMScript.getVictoryRed();
        blue_victory = GPMScript.getVictoryBlue();
    }

    private void setArmyVal()
    {
        red_army = GPMScript.getRedArmy();
        blue_army = GPMScript.getBlueArmy();
    }

    private void whichArmy()
    {
        if(turn_color == 1)
        {
            cur_army = red_army;
        }
        else
        {
            cur_army = blue_army;
        }
    }

    private void setResVal()
    {
        resource_red = GPMScript.getRedRes();
        resource_blue = GPMScript.getBlueRes();
    }

    private void whichRes()
    {
        if (turn_color == 1)
        {
            cur_res = resource_red;
        }
        else
        {
            cur_res = resource_blue;
        }
    }
}
