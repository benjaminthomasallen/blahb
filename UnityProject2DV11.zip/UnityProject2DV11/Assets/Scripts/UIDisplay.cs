﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UIDisplay : MonoBehaviour {

    public Text armySizeText;
    public Text resourceText;
    public Text infoText;
    public Text victoryText;
    public Text currentTurnText;

    private string currentUnit;
    private string unitTeam;
    private int hp;
    private int atk;
    private int def;
    private int move;
    private int sight;
    private int range;

    private string currentTurn;

    // Use this for initialization
    void Start () {

        getUnitInfo();
        infoText.text = "Unit: " + currentUnit + "\nTeam: " + unitTeam + "\n\nHP: " + hp + "\nAtk: " + atk + "\nDef: " + def + "\nMove: " + move + "\nSight: " + sight + "\nRange: " + range;
    }
	
	// Update is called once per frame
	void Update () {

        getUnitInfo();
        infoText.text = "Unit: " + currentUnit + "\nTeam: " + unitTeam + "\n\nHP: " + hp+ "\nAtk: " + atk + "\nDef: " + def + "\nMove: " + move + "\nSight: " + sight + "\nRange: " + range;

    }

    private void getUnitInfo()
    {
        currentUnit = "Heavy Knight";
        unitTeam = "Red";
        hp = 25;
        atk = 8;
        def = 6;
        move = 2;
        sight = 2;
        range = 1;
    }

    private void setCurrentTurn(int team)
    {
        if (team == 1)
        {
            currentTurn = "RED";
        }
        else
        {
            currentTurn = "BLUE";
        }
    }
}
