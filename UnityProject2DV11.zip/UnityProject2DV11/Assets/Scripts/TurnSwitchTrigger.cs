﻿using UnityEngine;
using System.Collections;

public class TurnSwitchTrigger : MonoBehaviour {

    private GameplayManager GPMScript;

    // Use this for initialization
    void Start () {
        GPMScript = GameObject.Find("GameManager(Clone)").GetComponent<GameplayManager>();
    }
	
	// Update is called once per frame
	void Update () {
	
	}

    public void activateSwitch()
    {
        GPMScript.switchTurn();
    }
}
