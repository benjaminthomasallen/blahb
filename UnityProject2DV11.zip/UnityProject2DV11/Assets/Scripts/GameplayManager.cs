﻿using UnityEngine;
using System.Collections;

public class GameplayManager : MonoBehaviour
{

    public DefaultUnit[,] PlayerUnits = new DefaultUnit[20, 50];
    public GameObject redSwordsmanPrefab;
    public GameObject redKnightPrefab;
    public GameObject redHeavyKnightPrefab;
    public GameObject redArcherPrefab;
    public GameObject redLongbowmanPrefab;
    public GameObject redCrossbowmanPrefab;
    public GameObject redScoutPrefab;
    public GameObject redHorsemanPrefab;
    public GameObject redCalvaryPrefab;
    public GameObject redAssassinPrefab;
    public GameObject redCatapultPrefab;
    public GameObject blueSwordsmanPrefab;
    public GameObject blueKnightPrefab;
    public GameObject blueHeavyKnightPrefab;
    public GameObject blueArcherPrefab;
    public GameObject blueLongbowmanPrefab;
    public GameObject blueCrossbowmanPrefab;
    public GameObject blueScoutPrefab;
    public GameObject blueHorsemanPrefab;
    public GameObject blueCalvaryPrefab;
    public GameObject blueAssassinPrefab;
    public GameObject blueCatapultPrefab;

    private Transform UnitHolder;
    private Vector2 mouseOver;
    private float minorOffset = 0.3f;
    private DefaultUnit selectedUnit;
    private Vector2 startDrag;
    private Vector2 endDrag;

    private int[,] possible = new int[20, 50];
    private BoardManager BScript;
    private GameObject shader;
    private Vector2[] tileCollection = new Vector2[500];
    private GameObject[] requestedTile = new GameObject[500];
    private int iteratorCount = 0;
    private int team_color = 1;

    private int resource_red = 0;
    private int resource_blue = 0;
    private int red_victory = 0;
    private int blue_victory = 0;
    private int red_army = 0;
    private int blue_army = 0;

    private HUDManager HUDscript;
    private DefaultUnit store_data;


    // Use this for initialization
    void Start()
    {
        //SpawnUnits ();
        BScript = GameObject.Find("GameManager(Clone)").GetComponent<BoardManager>();
        HUDscript = GameObject.Find("HUDManager(Clone)").GetComponent<HUDManager>();
    }

    // Update is called once per frame
    void Update()
    {
        UpdateMouseOver();

        int x = (int)mouseOver.x;
        int y = (int)mouseOver.y;

        if (selectedUnit != null)
            UpdateUnitMove(selectedUnit);

        if (Input.GetMouseButtonDown(0))
            SelectUnit(x, y);

        if (Input.GetMouseButtonUp(0))
            TryMove((int)startDrag.x, (int)startDrag.y, x, y);

    }

    private void UpdateMouseOver()
    {
        RaycastHit hit;

        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("Tile")))
        {
            mouseOver.x = (int)(hit.point.x + minorOffset);
            mouseOver.y = (int)(hit.point.y + minorOffset);
        }
        else
        {
            mouseOver.x = -1;
            mouseOver.y = -1;
        }
    }

    private void UpdateUnitMove(DefaultUnit defUnit)
    {
        RaycastHit hit;

        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("Tile")))
        {
            defUnit.transform.position = hit.point;
        }
    }

    private void SelectUnit(int x, int y)
    {
        if (x < 0 || x >= 20 || y < 0 || y >= 50)
        {
            return;
        }

        DefaultUnit defUnit = PlayerUnits[x, y];
        if (defUnit != null)
        {
            //do the info box storing here
            store_data = PlayerUnits[x, y];
            if (team_color == defUnit.whichteam() && defUnit.activity())
            {

                selectedUnit = defUnit;
                startDrag = mouseOver;
                Debug.Log(selectedUnit.name);
                resetPossible();
                int move;
                move = selectedUnit.move;
                findMovement(move, x, y, x, y);
                doShade();
            }

        }
    }

    private void TryMove(int x1, int y1, int x2, int y2)
    {
        if (possible[x2, y2] == 2)
        {
            int diff_x = Mathf.Abs(x2 - x1);
            int diff_y = Mathf.Abs(y2 - y1);
            if (diff_x + diff_y == 1)
            {
                atkEnemy(x1, y1, x2, y2);
                startDrag = new Vector2(x1, y1);
                endDrag = new Vector2(x2, y2);
                selectedUnit = PlayerUnits[x1, y1];

                MoveUnit(selectedUnit, x1, y1);

                if (x2 == x1 && y2 == y1)
                {
                    ;
                }
                else
                {
                    PlayerUnits[x1, y1] = selectedUnit;
                    MoveUnit(selectedUnit, x1, y1);
                }
                selectedUnit.setActivity(false);
                selectedUnit.GetComponent<SpriteRenderer>().color = new Color(0.4f, 0.4f, 0.4f);
                EndMovement();
                undoShade();

                return;
            }
        }

        // limited movement checker "You cannot move"
        if (possible[x2, y2] == 0)
        {
            startDrag = new Vector2(x1, y1);
            endDrag = new Vector2(x2, y2);
            selectedUnit = PlayerUnits[x1, y1];

            MoveUnit(selectedUnit, x1, y1);

            if (x2 == x1 && y2 == y1)
            {
                ;
            }
            else
            {
                PlayerUnits[x1, y1] = selectedUnit;
                MoveUnit(selectedUnit, x1, y1);
            }
            EndMovement();
            undoShade();

            return;
        }

        // You can move
        startDrag = new Vector2(x1, y1);
        endDrag = new Vector2(x2, y2);
        selectedUnit = PlayerUnits[x1, y1];

        MoveUnit(selectedUnit, x2, y2);

        if (x2 == x1 && y2 == y1)
        {
            ;
        }
        else
        {
            PlayerUnits[x2, y2] = selectedUnit;
            PlayerUnits[x1, y1] = null;
            MoveUnit(selectedUnit, x2, y2);
        }
        selectedUnit.setActivity(false);
        selectedUnit.GetComponent<SpriteRenderer>().color = new Color(0.4f, 0.4f, 0.4f);
        EndMovement();
        undoShade();
    }

    private void atkEnemy(int x1, int y1, int x2, int y2)
    {
        int atk = PlayerUnits[x1, y1].att;
        int hp = PlayerUnits[x2, y2].hp;
        PlayerUnits[x2, y2].setHP(hp - atk);
        if (hp - atk < 1)
        {
            int val_color = PlayerUnits[x2, y2].whichteam();
            if(val_color == 1)
            {
                red_army--;
            }
            else
            {
                blue_army--;
            }
            PlayerUnits[x2, y2].GetComponent<SpriteRenderer>().enabled = false;
            Destroy(PlayerUnits[x2, y2]);
        }
        PlayerUnits[x1, y1].setActivity(false);
    }

    private void EndMovement()
    {
        selectedUnit = null;
        startDrag = Vector2.zero;
    }

    public void switchTurn()
    {
        if (team_color == 1)
        {
            team_color = 2;
        }
        else if(team_color == 2)
        {
            team_color = 1;
        }
        else
        {
            team_color = 3;
            return;
        }
        for (int x = 0; x < 20; x++)
            for (int y = 0; y < 50; y++)
            {
                //reset the activity of units and unshade them after each turn.
                if (PlayerUnits[x, y] != null)
                {
                    PlayerUnits[x, y].setActivity(true);
                    PlayerUnits[x, y].GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f);
                }

            }

        int i, j, k;
        int red_resource_spots_on = 0;
        int blue_resource_spots_on = 0;
        for (i = 0; i < 20; i++)
        {
            for (j = 0; j < 50; j++)
            {
                if (PlayerUnits[i, j] != null && isResource(i, j) == 1)
                {
                    if (PlayerUnits[i, j].whichteam() == 1)
                    {
                        red_resource_spots_on++;
                    }
                    if (PlayerUnits[i, j].whichteam() == 2)
                    {
                        blue_resource_spots_on++;
                    }
                }
                if (PlayerUnits[i, j] != null && isPowerSpot(i, j) == 1)
                {
                    if (PlayerUnits[i, j].whichteam() == 1)
                    {
                        red_victory++;
                    }
                    if (PlayerUnits[i, j].whichteam() == 2)
                    {
                        blue_victory++;
                    }
                }
            }
        }
        resource_red += 50 * red_resource_spots_on;
        resource_blue += 50 * blue_resource_spots_on;
        if(red_victory >= 20 || blue_victory >= 20)
        {
            team_color = 3;
        }
    }
    //make a prebuilt army
    public void SpawnUnits()
    {

        UnitHolder = new GameObject("Units").transform;

        InstantiateUnit(redKnightPrefab, 4, 3, 1, "Knight");
        InstantiateUnit(redArcherPrefab, 5, 3, 1, "Archer");
        InstantiateUnit(redAssassinPrefab, 6, 3, 1, "Assassin");
        InstantiateUnit(redCalvaryPrefab, 7, 3, 1, "Calvary");
        InstantiateUnit(redCatapultPrefab, 8, 3, 1, "Catapult");
        InstantiateUnit(redCrossbowmanPrefab, 9, 3, 1, "CrossBowMan");
        InstantiateUnit(redHeavyKnightPrefab, 10, 3, 1, "HeavyKnight");
        InstantiateUnit(redHorsemanPrefab, 11, 3, 1, "HorseMan");
        InstantiateUnit(redKnightPrefab, 12, 3, 1, "Knight");
        InstantiateUnit(redLongbowmanPrefab, 13, 3, 1, "LongBowMan");
        InstantiateUnit(redScoutPrefab, 14, 3, 1, "Scout");
        InstantiateUnit(redSwordsmanPrefab, 15, 3, 1, "SwordsMan");
        red_army += 11;

        InstantiateUnit(blueKnightPrefab, 4, 46, 2, "Knight");
        InstantiateUnit(blueArcherPrefab, 5, 46, 2, "Archer");
        InstantiateUnit(blueAssassinPrefab, 6, 46, 2, "Assassin");
        InstantiateUnit(blueCalvaryPrefab, 7, 46, 2, "Calvary");
        InstantiateUnit(blueCatapultPrefab, 8, 46, 2, "Catapult");
        InstantiateUnit(blueCrossbowmanPrefab, 9, 46, 2, "CrossBowMan");
        InstantiateUnit(blueHeavyKnightPrefab, 10, 46, 2, "HeavyKnight");
        InstantiateUnit(blueHorsemanPrefab, 11, 46, 2, "HorseMan");
        InstantiateUnit(blueKnightPrefab, 12, 46, 2, "Knight");
        InstantiateUnit(blueLongbowmanPrefab, 13, 46, 2, "LongBowMan");
        InstantiateUnit(blueScoutPrefab, 14, 46, 2, "Scout");
        InstantiateUnit(blueSwordsmanPrefab, 15, 46, 2, "SwordsMan");
        blue_army += 11;
    }

    private void InstantiateUnit(GameObject unitType, int x, int y, int team_number, string type)
    {
        GameObject tempGO = Instantiate(unitType, new Vector3(0f, 0f, 0f), Quaternion.identity) as GameObject;
        tempGO.transform.SetParent(UnitHolder);
        DefaultUnit defUnit = tempGO.GetComponent<DefaultUnit>();
        defUnit.setTeam(team_number);
        defUnit.setUnitStats(type);
        PlayerUnits[x, y] = defUnit;
        MoveUnit(defUnit, x, y);
    }

    private void MoveUnit(DefaultUnit defUnit, int x, int y)
    {
        defUnit.transform.position = (Vector3.right * x) + (Vector3.up * y);
    }

    private void findMovement(int move, int x, int y, int orig_x, int orig_y)
    {
        if (x < 0 || x >= 20 || y < 0 || y >= 50)
        {
            return;
        }
        possible[x, y] = 1;
        int terrainCost = getTerrainTypeCost(x, y);
        //check if we are on a tile we should not be on
        if (terrainCost == -1)
        {
            //if on a tile we cant be on, switch possible to 0, and end this loop
            possible[x, y] = 0;
            return;
        }

        if (x == orig_x && y == orig_y)
        {
            possible[x, y] = 1;
            tileCollection[iteratorCount].x = x;
            tileCollection[iteratorCount].y = y;
            iteratorCount++;
        }
        else if (PlayerUnits[x, y] != null)
        {
            possible[x, y] = 0;
            //check if enemy or ally
            if (PlayerUnits[x, y].whichteam() != team_color)
            {
                possible[x, y] = 2;
                return;
            }
        }
        else
        {
            tileCollection[iteratorCount].x = x;
            tileCollection[iteratorCount].y = y;
            iteratorCount++;
        }

        //if we have no more movement left, we are done moving end loop
        if (move <= 0) return;

        //when we are here we are on a possible tile, and we then go to the neighboring spots using our move cost
        findMovement(move - terrainCost, x - 1, y, orig_x, orig_y);
        findMovement(move - terrainCost, x + 1, y, orig_x, orig_y);
        findMovement(move - terrainCost, x, y - 1, orig_x, orig_y);
        findMovement(move - terrainCost, x, y + 1, orig_x, orig_y);
    }

    private int getTerrainTypeCost(int x, int y)
    {
        GameObject curTile;
        curTile = BScript.PassObject(x, y);
        //If we are on a grass or resource tile
        if (curTile.tag == "Grass" || curTile.tag == "Resource" || curTile.tag == "Powerspot")
        {
            return 1;
        }
        //if on a rock tile
        else if (curTile.tag == "Rocky")
        {
            return 2;
        }
        //Else we are on a player1base, player2base, power, water, enemy Tile
        //and cannot move on it so return -1
        return -1;

    }

    private void resetPossible()
    {
        //sets all values in possible to zero
        int i, j, k;
        for (i = 0; i < 20; i++)
        {
            for (j = 0; j < 50; j++)
            {
                possible[i, j] = 0;
            }
        }
    }

    private int getPlayerMove(int x, int y)
    {
        int value = PlayerUnits[x, y].move;
        return value;
    }

    private void doShade()
    {
        int i, j, k;
        for (i = 0; i < iteratorCount; i++)
        {
            requestedTile[i] = BScript.PassObject((int)tileCollection[i].x, (int)tileCollection[i].y);
            requestedTile[i].GetComponent<SpriteRenderer>().color = new Color(0.5f, 0.5f, 0.5f);
        }
    }

    private void undoShade()
    {
        int i, j, k;
        for (i = 0; i < iteratorCount; i++)
        {
            requestedTile[i] = BScript.PassObject((int)tileCollection[i].x, (int)tileCollection[i].y);
            requestedTile[i].GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f);
        }
        iteratorCount = 0;
    }

    private int isResource(int x, int y)
    {
        GameObject curTile;
        curTile = BScript.PassObject(x, y);
        if (curTile.tag == "Resource")
        {
            return 1;
        }

        return 0;
    }
    private int isPowerSpot(int x, int y)
    {
        GameObject curTile;
        curTile = BScript.PassObject(x, y);
        if (curTile.tag == "Powerspot")
        {
            return 1;
        }

        return 0;
    }

    public int getVictoryRed()
    {
        return red_victory;
    }
    public int getVictoryBlue()
    {
        return blue_victory;
    }
    public int getTurnColor()
    {
        return team_color;
    }
    public int getRedArmy()
    {
        return red_army;
    }
    public int getBlueArmy()
    {
        return blue_army;
    }
    public int getBlueRes()
    {
        return resource_blue;
    }
    public int getRedRes()
    {
        return resource_red;
    }
    public DefaultUnit getData()
    {
        return store_data;
    }

}
